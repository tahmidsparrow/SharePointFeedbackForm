export interface IThirdPartyApiCallProps {
    description: string;
    isDarkTheme: boolean;
    environmentMessage: string;
    hasTeamsContext: boolean;
    userDisplayName: string;
}
//# sourceMappingURL=IThirdPartyApiCallProps.d.ts.map