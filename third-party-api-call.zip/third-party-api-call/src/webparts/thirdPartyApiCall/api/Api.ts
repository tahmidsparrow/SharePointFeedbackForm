import { IGeneralResponse } from '../types/Types';

const BASE_URL = 'http://localhost:8080/_api';

export const sampleGetRequest = async (): Promise<IGeneralResponse> => {
	const response = await fetch(`${BASE_URL}/test-get`);
	const data = await response.json();
	return data;
};

export const samplePostRequest = async (): Promise<IGeneralResponse> => {
	const response = await fetch(`${BASE_URL}/test-post`, {
		method: 'POST',
		headers: {
			'Content-Type': 'application/json',
		},
		body: JSON.stringify({ request: 'test post request' }),
	});
	const data = await response.json();
	return data;
};
