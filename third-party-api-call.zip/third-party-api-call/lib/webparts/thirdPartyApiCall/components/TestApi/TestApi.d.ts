/// <reference types="react" />
declare const TestApi: () => JSX.Element;
export default TestApi;
//# sourceMappingURL=TestApi.d.ts.map