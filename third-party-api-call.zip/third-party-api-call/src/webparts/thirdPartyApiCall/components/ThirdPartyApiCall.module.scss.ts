/* tslint:disable */
require("./ThirdPartyApiCall.module.css");
const styles = {
  thirdPartyApiCall: 'thirdPartyApiCall_14d11de4',
  teams: 'teams_14d11de4',
  welcome: 'welcome_14d11de4',
  welcomeImage: 'welcomeImage_14d11de4',
  links: 'links_14d11de4'
};

export default styles;
/* tslint:enable */