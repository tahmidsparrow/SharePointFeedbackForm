import * as React from 'react';
import { IThirdPartyApiCallProps } from './IThirdPartyApiCallProps';
import TestApi from './TestApi/TestApi';
import 'bootstrap/dist/css/bootstrap.min.css';

export default class ThirdPartyApiCall extends React.Component<
	IThirdPartyApiCallProps,
	{}
> {
	public render(): React.ReactElement<IThirdPartyApiCallProps> {
		return <TestApi />;
	}
}
