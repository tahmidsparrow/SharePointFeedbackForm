import * as React from 'react';
import { useState } from 'react';
import { sampleGetRequest, samplePostRequest } from '../../api/Api';
import { IGeneralResponse } from '../../types/Types';

const TestApi = (): JSX.Element => {
	const [responses, setResponses] = useState<IGeneralResponse[]>([]);

	const testGetRequest = async (): Promise<void> => {
		const response = await sampleGetRequest();

		setResponses([...responses, response]);
	};

	const testPostRequest = async (): Promise<void> => {
		const response = await samplePostRequest();

		setResponses([...responses, response]);
	};

	const handleGetRequestButtonClick = async (): Promise<void> => {
		console.log('Get Request Button Clicked');
		await testGetRequest();
	};

	const handlePostRequestButtonClick = async (): Promise<void> => {
		console.log('Post Request Button Clicked');
		await testPostRequest();
	};

	return (
		<div className='container'>
			<div className='row'>
				<div className='col-12'>
					<h1>Test Api</h1>
					<div className='btn-group btn-group-lg mb-3'>
						<button
							className='btn btn-secondary'
							onClick={handleGetRequestButtonClick}
						>
							Get Request
						</button>
						<button
							className='btn btn-secondary'
							onClick={handlePostRequestButtonClick}
						>
							Post Request
						</button>
					</div>
					{/* show all responses */}
					<div className='row'>
						<div className='col-12'>
							<h2>Responses:</h2>
							{responses.map((response, index) => (
								<div key={index}>
									{JSON.stringify(response)}
									<hr />
								</div>
							))}
						</div>
					</div>
				</div>
			</div>
		</div>
	);
};

export default TestApi;
