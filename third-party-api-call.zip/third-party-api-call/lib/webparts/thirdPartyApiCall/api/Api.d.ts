import { IGeneralResponse } from '../types/Types';
export declare const sampleGetRequest: () => Promise<IGeneralResponse>;
export declare const samplePostRequest: () => Promise<IGeneralResponse>;
//# sourceMappingURL=Api.d.ts.map