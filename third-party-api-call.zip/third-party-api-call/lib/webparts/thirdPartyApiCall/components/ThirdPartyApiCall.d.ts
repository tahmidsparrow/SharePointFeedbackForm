import * as React from 'react';
import { IThirdPartyApiCallProps } from './IThirdPartyApiCallProps';
import 'bootstrap/dist/css/bootstrap.min.css';
export default class ThirdPartyApiCall extends React.Component<IThirdPartyApiCallProps, {}> {
    render(): React.ReactElement<IThirdPartyApiCallProps>;
}
//# sourceMappingURL=ThirdPartyApiCall.d.ts.map