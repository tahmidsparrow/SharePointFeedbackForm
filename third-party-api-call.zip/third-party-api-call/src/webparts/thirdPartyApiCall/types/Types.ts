export interface IGeneralResponse {
	message: string;
	status: string;
	data: unknown;
}
