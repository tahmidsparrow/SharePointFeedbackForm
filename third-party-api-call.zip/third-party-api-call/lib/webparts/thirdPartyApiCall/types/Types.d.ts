export interface IGeneralResponse {
    message: string;
    status: string;
    data: unknown;
}
//# sourceMappingURL=Types.d.ts.map